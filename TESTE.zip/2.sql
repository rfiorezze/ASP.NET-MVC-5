SELECT 
	Clientes.Nome
	Clientes.Cnpj
	Pedidos.Numero
	Pedidos.Data
	CASE Pedidos.Valor 
		WHEN IS NULL THEN 0
		ELSE Pedidos.Valor 
	END
FROM Cliente
LEFT JOIN Pedidos
	ON Clientes.ClienteId=Pedidos=ClienteId