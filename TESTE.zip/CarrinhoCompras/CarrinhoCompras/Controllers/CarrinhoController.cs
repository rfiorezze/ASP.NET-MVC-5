﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.Mvc;
using CarrinhoCompras.Models;

namespace CarrinhoCompras.Controllers
{
    public class CarrinhoController : Controller
    {
        // GET: Carrinho
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult ListarCarrinho()
        {

            Carrinho carrinho = (Carrinho)Session["Carrinho"];


            return View(carrinho);
        }
        [HttpPost]// Ingessei deste jeito pois os parametros só vinha nulos, tentei usar POST e AJAX passando JSON :(
        public ActionResult EnviarEmail(string email,int qtd1, int qtd2)
            {
            Carrinho carrinho = (Carrinho)Session["Carrinho"];

            carrinho.Produtos[0].Quantidade = qtd1;
            carrinho.Produtos[1].Quantidade = qtd2;

            StringBuilder bodyMail = new StringBuilder("Segue abaixo os ítens comprados e suas respectivas quantidades:");
            bodyMail.Append(Environment.NewLine);
            bodyMail.Append(Environment.NewLine);
            foreach (var item in carrinho.Produtos)
            {
                bodyMail.Append(Environment.NewLine);
                bodyMail.AppendLine(item.Descricao+" - Qtd: "+item.Quantidade);
                bodyMail.Append(Environment.NewLine);
            }

            MailAddress mailTo = new MailAddress(email);
            MailAddress mailFrom = new MailAddress("abscardteste@gmail.com");
            string msg = "";
            if (!Mail(mailTo,mailFrom,"Resumo da sua compra",bodyMail.ToString()))
                msg = "Erro ao enviar Mensagem";
                
            return Json(new { mensagem = msg });
        }

        public bool Mail(MailAddress to, MailAddress from, string sub, string body)
        {
            var m = new MailMessage()
            {
                Subject = sub,
                Body = body,
                IsBodyHtml = true
            };
            to = new MailAddress("renato.fiorezze@gmail.com", "Renato");
            m.To.Add(to);
            m.From = new MailAddress(from.ToString());
            m.Sender = to;

            var smtp = new SmtpClient
            {
                Host = "smtp.gmail.com",
                Port = 587,
                Credentials = new NetworkCredential("abscardteste@gmail.com", "teste1596"),
                EnableSsl = true
            };
            try
            {
                smtp.Send(m);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
    }

}