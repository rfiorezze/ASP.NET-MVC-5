﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CarrinhoCompras.Models;

namespace CarrinhoCompras.Controllers
{
    public class ProdutoController : Controller
    {
        // GET: Produto
        public ActionResult Index()
        {
            List<Produto> Produtos = new List<Produto>();
            Produtos.Add(new Produto(1, "Item 1", 0));
            Produtos.Add(new Produto(2, "Item 2", 0));
            Carrinho carrinho =  new Carrinho(null,Produtos);
            Session["Carrinho"] = carrinho;
            return View(carrinho);
        }

        [HttpPost]
        public ActionResult ValidarCarrinho(string email)
        {
            string msg = "";
            bool itens=false;
            Carrinho carrinho = (Carrinho)Session["Carrinho"];
            carrinho.Email = email;

            foreach (var item in carrinho.Produtos)
            {
                if (item.Quantidade != 0)
                    itens = true;
            }

            if (!itens)
                msg = "Não há itens no carrinho.";

            
            return Json(new { mensagem = msg });

        }       

        [HttpPost]
        public ActionResult AdicionarAoCarrinho(int id,int quantidade)
        {
            string msg="";
            Carrinho carrinho = (Carrinho)Session["Carrinho"];

            try
            {
                foreach (var item in carrinho.Produtos)
                {
                    if (item.Id == id)
                    {
                        item.Quantidade += quantidade;
                        break;
                    }
                }
            }
            catch (Exception ex )
            {
                msg = ex.Message;               
            }

            return Json(new { mensagem = msg });
        }
    }
}