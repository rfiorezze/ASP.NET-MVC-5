﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarrinhoCompras.Models
{
    public class Produto
    {
        public int Id { get; set; }
        public String Descricao { get; set; }
        public int Quantidade { get; set; }

        public Produto(int id,String descricao,int quantidade)
        {
            Id = id;
            Descricao = descricao;
            Quantidade = quantidade;
        }
    }
}