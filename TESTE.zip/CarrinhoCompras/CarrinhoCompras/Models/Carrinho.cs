﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CarrinhoCompras.Models
{
    public class Carrinho
    {
        [Required(ErrorMessage = "Informe o Email")]
        public string Email { get; set; }
        public List<Produto> Produtos { get; set; }

        public Carrinho(string email,List<Produto>produtos) {

            Email = email;
            Produtos = produtos;
        }       
    }
}